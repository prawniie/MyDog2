﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyDog
{
    class Ring
    {
        public int Id { get; set; }
        public int Number { get; set; }
    }
}
