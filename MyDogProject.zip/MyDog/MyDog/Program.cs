﻿using System;

namespace MyDog
{
    class Program
    {
        static void Main(string[] args)
        {
            var app = new App();
            app.Run();
        }
    }
}
